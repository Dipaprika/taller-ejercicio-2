import './App.css';
import React, {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Dropdown, DropdownItem, DropdownMenu, DropdownToggle} from 'reactstrap';
import {data} from "./data";


function App() {
  const [dropdown, setDropdown] = useState(false);

  const abrirCerrarDropdown=()=>{
    setDropdown(!dropdown);
  }
  return (
    <div className="App">
      <Dropdown isOpen={dropdown} toggle={abrirCerrarDropdown} size='lg'>
         <DropdownToggle caret className='botonDropdown'>
           Menu de la tienda
         </DropdownToggle>
      {data.map(product =>(
        <div  className="info-product">
        <DropdownMenu >
          
          <DropdownItem >
            
            <h2>{product.title}</h2> 
            <p className="price">${product.price}</p>

          </DropdownItem>
         
        </DropdownMenu>
        </div>

      ))}
      </Dropdown>
    </div>
  );
}

export default App;
