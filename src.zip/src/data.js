export const data=[
    {
        id:1,
        title:'Rolon',
        price:2,
        quantity:1
    },
    {
        id:2,
        title:'Shampoo',
        price:4,
        quantity:1
    },
    {
        id:3,
        title:'Papel Higienico',
        price:8,
        quantity:1
    },
    {
        id:4,
        title:'Cepillo Dental',
        price:1,
        quantity:1
    }, {
        id:5,
        title:'Pasta Dental',
        price:3,
        quantity:1
    },{
        id:6,
        title:'Acondicionador',
        price:5,
        quantity:1
    },{
        id:7,
        title:'Locion',
        price:6,
        quantity:1
    },{
        id:8,
        title:'Crema',
        price:7,
        quantity:1
    },{
        id:9,
        title:'Bloqueador Solar',
        price:10,
        quantity:1
    },{
        id:10,
        title:'Rasuradora',
        price:1,
        quantity:1
    }
];
